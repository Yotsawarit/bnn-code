"use client";

import { useState, useEffect, useRef, type ReactNode } from "react";
import { motion, useInView } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Separator } from "@/components/ui/separator";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import {
  Terminal,
  Cpu,
  Database,
  Search,
  Code2,
  GitBranch,
  Download,
  ChevronRight,
  Copy,
  Check,
  Github,
  ArrowRight,
  Zap,
  Brain,
  TreePine,
  Monitor,
  Puzzle,
  FileCode2,
  FolderTree,
  Keyboard,
  Package,
  Rocket,
  FlaskConical,
  Gauge,
  BookOpen,
  GitPullRequest,
  Users,
  Hammer,
  Target,
  Lightbulb,
  Shield,
  Timer,
  HardDrive,
  Sparkles,
  FileText,
  Layers,
} from "lucide-react";
import { toast } from "sonner";
import Image from "next/image";

/* ──────────────────────────── Animation helpers ──────────────────────────── */

function FadeIn({
  children,
  className = "",
  delay = 0,
}: {
  children: ReactNode;
  className?: string;
  delay?: number;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true, margin: "-60px" });
  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 24 }}
      animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 24 }}
      transition={{ duration: 0.5, delay, ease: "easeOut" }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

function StaggerContainer({
  children,
  className = "",
}: {
  children: ReactNode;
  className?: string;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true, margin: "-40px" });
  return (
    <motion.div
      ref={ref}
      initial="hidden"
      animate={inView ? "visible" : "hidden"}
      variants={{
        hidden: {},
        visible: { transition: { staggerChildren: 0.08 } },
      }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

const staggerItem = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.45, ease: "easeOut" } },
};

/* ──────────────────────────── Copy Button ──────────────────────────── */

function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <button
      onClick={() => {
        navigator.clipboard.writeText(text);
        setCopied(true);
        toast.success("Copied to clipboard");
        setTimeout(() => setCopied(false), 2000);
      }}
      className="absolute top-3 right-3 p-1.5 rounded-md bg-white/5 hover:bg-white/10 transition-colors text-muted-foreground hover:text-foreground"
      aria-label="Copy to clipboard"
    >
      {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
    </button>
  );
}

/* ──────────────────────────── Code Block ──────────────────────────── */

function CodeBlock({
  code,
  language = "bash",
}: {
  code: string;
  language?: string;
}) {
  return (
    <div className="relative rounded-xl bg-zinc-950 border border-white/5 overflow-hidden">
      <div className="flex items-center gap-2 px-4 py-2.5 border-b border-white/5">
        <div className="flex gap-1.5">
          <span className="w-3 h-3 rounded-full bg-red-500/60" />
          <span className="w-3 h-3 rounded-full bg-yellow-500/60" />
          <span className="w-3 h-3 rounded-full bg-green-500/60" />
        </div>
        <span className="text-xs text-muted-foreground font-mono ml-2">
          {language}
        </span>
      </div>
      <div className="p-4 overflow-x-auto max-h-80">
        <pre className="code-block text-sm font-mono leading-relaxed text-zinc-300">
          {code.split("\n").map((line, i) => (
            <div key={i} className="line">
              <span
                dangerouslySetInnerHTML={{
                  __html: highlightSyntax(line, language),
                }}
              />
            </div>
          ))}
        </pre>
      </div>
      <CopyButton text={code} />
    </div>
  );
}

function highlightSyntax(line: string, lang: string): string {
  let escaped = line
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");

  if (lang === "bash" || lang === "sh") {
    escaped = escaped.replace(
      /(#.*)$/,
      '<span class="text-zinc-500">$1</span>'
    );
    escaped = escaped.replace(
      /^(\$\s)/,
      '<span class="text-amber-400">$1</span>'
    );
    escaped = escaped.replace(
      /\b(sudo|tar|cd|cargo|bash|python3|mv|unzip|bun|npm|RUSTFLAGS)\b/g,
      '<span class="text-amber-400">$1</span>'
    );
    escaped = escaped.replace(
      /\b(bnn-code)\b/g,
      '<span class="text-emerald-400 font-semibold">$1</span>'
    );
  } else if (lang === "toml") {
    escaped = escaped.replace(
      /(#.*)$/,
      '<span class="text-zinc-500">$1</span>'
    );
    escaped = escaped.replace(
      /(".*?")/g,
      '<span class="text-emerald-400">$1</span>'
    );
    escaped = escaped.replace(
      /\b(\d+\.?\d*)\b/g,
      '<span class="text-amber-400">$1</span>'
    );
  } else if (lang === "lua") {
    escaped = escaped.replace(
      /(--.*)$/,
      '<span class="text-zinc-500">$1</span>'
    );
    escaped = escaped.replace(
      /(".*?")/g,
      '<span class="text-emerald-400">$1</span>'
    );
  }
  return escaped;
}

/* ──────────────────────────── Section Header ──────────────────────────── */

function SectionHeader({
  badge,
  title,
  description,
}: {
  badge: string;
  title: string;
  description: string;
}) {
  return (
    <div className="text-center max-w-2xl mx-auto mb-12 md:mb-16">
      <Badge
        variant="outline"
        className="mb-4 border-amber-500/30 text-amber-400 bg-amber-500/5"
      >
        {badge}
      </Badge>
      <h2 className="text-3xl md:text-4xl font-bold tracking-tight mb-4">
        {title}
      </h2>
      <p className="text-muted-foreground text-lg leading-relaxed">
        {description}
      </p>
    </div>
  );
}

/* ──────────────────────────── Feature Card ──────────────────────────── */

function FeatureCard({
  icon: Icon,
  title,
  description,
}: {
  icon: React.ElementType;
  title: string;
  description: string;
}) {
  return (
    <motion.div variants={staggerItem}>
      <Card className="group relative bg-card/50 backdrop-blur-sm border-white/5 hover:border-amber-500/20 transition-all duration-300 hover:bg-card/80 h-full">
        <CardHeader className="pb-3">
          <div className="w-10 h-10 rounded-lg bg-amber-500/10 flex items-center justify-center mb-3 group-hover:bg-amber-500/20 transition-colors">
            <Icon className="w-5 h-5 text-amber-400" />
          </div>
          <CardTitle className="text-lg font-semibold">{title}</CardTitle>
        </CardHeader>
        <CardContent>
          <CardDescription className="text-muted-foreground leading-relaxed">
            {description}
          </CardDescription>
        </CardContent>
      </Card>
    </motion.div>
  );
}

/* ──────────────────────────── Architecture Diagram ──────────────────────────── */

function ArchitectureDiagram() {
  const layers = [
    {
      label: "Editor Integrations",
      items: ["VS Code Extension", "Neovim Plugin"],
      color: "from-rose-500/20 to-rose-600/5 border-rose-500/20",
      iconColor: "text-rose-400",
    },
    {
      label: "CLI (clap)",
      items: ["Argument Parsing", "Command Routing"],
      color: "from-violet-500/20 to-violet-600/5 border-violet-500/20",
      iconColor: "text-violet-400",
    },
    {
      label: "Core Engine",
      items: [
        "Indexer (AST · tree-sitter)",
        "Retrieval (SQLite FTS)",
        "Inference (ONNX Runtime + BNN)",
      ],
      color: "from-amber-500/20 to-amber-600/5 border-amber-500/20",
      iconColor: "text-amber-400",
    },
    {
      label: "Terminal UI",
      items: ["Ratatui + Crossterm", "Streaming Output", "Interactive TUI"],
      color: "from-emerald-500/20 to-emerald-600/5 border-emerald-500/20",
      iconColor: "text-emerald-400",
    },
  ];

  return (
    <div className="max-w-3xl mx-auto space-y-3">
      {layers.map((layer, i) => (
        <motion.div
          key={layer.label}
          initial={{ opacity: 0, x: -20 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ delay: i * 0.12, duration: 0.4 }}
        >
          <div
            className={`rounded-xl border bg-gradient-to-r ${layer.color} p-4 md:p-5`}
          >
            <div className="flex items-center gap-3 mb-2">
              <div
                className={`w-2 h-2 rounded-full bg-gradient-to-br ${layer.color.replace("/20", "/60").replace("border", "bg")}`}
              />
              <span className={`font-semibold text-sm ${layer.iconColor}`}>
                {layer.label}
              </span>
            </div>
            <div className="flex flex-wrap gap-2 ml-5">
              {layer.items.map((item) => (
                <Badge
                  key={item}
                  variant="secondary"
                  className="bg-white/5 text-foreground/80 text-xs font-normal"
                >
                  {item}
                </Badge>
              ))}
            </div>
          </div>
          {i < layers.length - 1 && (
            <div className="flex justify-center py-1">
              <ChevronRight className="w-4 h-4 text-muted-foreground/40 rotate-90" />
            </div>
          )}
        </motion.div>
      ))}
    </div>
  );
}

/* ──────────────────────────── Stats Counter ──────────────────────────── */

function AnimatedCounter({
  target,
  suffix = "",
}: {
  target: number;
  suffix?: string;
}) {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true });

  useEffect(() => {
    if (!inView) return;
    const duration = 1500;
    const startTime = Date.now();

    const tick = () => {
      const elapsed = Date.now() - startTime;
      const progress = Math.min(elapsed / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setCount(Math.round(eased * target));
      if (progress < 1) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  }, [inView, target]);

  return (
    <span
      ref={ref}
      className="text-3xl md:text-4xl font-bold text-amber-400 tabular-nums"
    >
      {count}
      {suffix}
    </span>
  );
}

/* ──────────────────────────── Demo Terminal ──────────────────────────── */

function DemoSection() {
  const [visibleLines, setVisibleLines] = useState(0);
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true, margin: "-100px" });

  const demoLines = [
    { text: "$ bnn-code index --path ./my-project", type: "input" },
    { text: "  Indexing 1,247 files with tree-sitter...", type: "info" },
    { text: "  ████████████████████████████████ 100%", type: "progress" },
    { text: "  Indexed 1,247 files · 48,392 chunks · 2.1s", type: "success" },
    { text: "", type: "blank" },
    { text: '$ bnn-code search "function that handles authentication"', type: "input" },
    { text: "  Found 3 results in 12ms", type: "info" },
    { text: "", type: "blank" },
    { text: "  src/auth/login.rs:42", type: "file" },
    { text: "    pub async fn authenticate_user(", type: "code" },
    { text: "        credentials: UserCredentials,", type: "code" },
    { text: "        db: &DatabasePool,", type: "code" },
    { text: "    ) -> Result<Session, AuthError> {", type: "code" },
    { text: "", type: "blank" },
    { text: '$ bnn-code query "How does the auth middleware work?"', type: "input" },
    { text: "  Running BNN inference (CodeBERTa-small)...", type: "info" },
    { text: "  The authentication middleware is defined in src/middleware/auth.rs.", type: "output" },
    { text: "  It uses a JWT token extracted from the Authorization header,", type: "output" },
    { text: "  validates it with the secret key, and attaches the user session", type: "output" },
    { text: "  to the request extensions. See `auth_middleware()` at line 15.", type: "output" },
  ];

  useEffect(() => {
    if (!inView) return;
    let i = 0;
    const interval = setInterval(() => {
      if (i < demoLines.length) {
        setVisibleLines(i + 1);
        i++;
      } else {
        clearInterval(interval);
      }
    }, 120);
    return () => clearInterval(interval);
  }, [inView, demoLines.length]);

  return (
    <section id="demo" className="py-20 md:py-28 px-4 sm:px-6 border-t border-white/5">
      <div className="max-w-6xl mx-auto">
        <SectionHeader
          badge="Demo"
          title="See it in action"
          description="BNN Code indexes your codebase, searches with SQLite FTS, and answers questions with on-device BNN inference — all from your terminal."
        />
        <FadeIn className="max-w-3xl mx-auto">
          <div
            ref={ref}
            className="rounded-2xl overflow-hidden border border-white/10 glow-amber bg-zinc-950"
          >
            {/* Terminal chrome */}
            <div className="flex items-center gap-2 px-4 py-3 bg-zinc-900 border-b border-white/5">
              <div className="flex gap-1.5">
                <span className="w-3 h-3 rounded-full bg-red-500/80" />
                <span className="w-3 h-3 rounded-full bg-yellow-500/80" />
                <span className="w-3 h-3 rounded-full bg-green-500/80" />
              </div>
              <span className="text-xs text-muted-foreground font-mono ml-3 flex items-center gap-1.5">
                <Terminal className="w-3 h-3" />
                bnn-code — ~/my-project
              </span>
            </div>
            {/* Terminal content */}
            <div className="p-5 font-mono text-sm leading-relaxed min-h-[420px]">
              {demoLines.slice(0, visibleLines).map((line, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ duration: 0.15 }}
                  className={`whitespace-pre ${
                    line.type === "input"
                      ? "text-amber-400"
                      : line.type === "file"
                        ? "text-cyan-400 mt-1"
                        : line.type === "code"
                          ? "text-zinc-400 pl-4"
                          : line.type === "success"
                            ? "text-emerald-400"
                            : line.type === "progress"
                              ? "text-amber-400/70"
                              : line.type === "output"
                                ? "text-zinc-300 pl-2"
                                : line.type === "info"
                                  ? "text-muted-foreground"
                                  : ""
                  }`}
                >
                  {line.text}
                </motion.div>
              ))}
              {visibleLines > 0 && visibleLines < demoLines.length && (
                <span className="inline-block w-2.5 h-5 bg-amber-400 cursor-blink ml-0.5 -mb-1" />
              )}
              {visibleLines >= demoLines.length && (
                <span className="inline-block w-2.5 h-5 bg-amber-400 cursor-blink ml-0.5 -mb-1" />
              )}
            </div>
          </div>
        </FadeIn>
      </div>
    </section>
  );
}

/* ──────────────────────────── Nav ──────────────────────────── */

function Navbar() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const links = [
    { label: "Features", href: "#features" },
    { label: "Demo", href: "#demo" },
    { label: "Install", href: "#installation" },
    { label: "Architecture", href: "#architecture" },
    { label: "Benchmarks", href: "#benchmarks" },
    { label: "Roadmap", href: "#roadmap" },
  ];

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? "bg-background/80 backdrop-blur-xl border-b border-white/5 shadow-lg shadow-black/10"
          : "bg-transparent"
      }`}
    >
      <nav className="max-w-6xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
        <a href="#" className="flex items-center gap-2.5 group">
          <div className="w-8 h-8 rounded-lg bg-amber-500/10 flex items-center justify-center group-hover:bg-amber-500/20 transition-colors">
            <Terminal className="w-4 h-4 text-amber-400" />
          </div>
          <span className="font-bold text-lg tracking-tight">BNN Code</span>
          <Badge
            variant="outline"
            className="text-[10px] px-1.5 py-0 border-amber-500/30 text-amber-400 bg-amber-500/5"
          >
            v0.1.3
          </Badge>
        </a>

        <div className="hidden lg:flex items-center gap-1">
          {links.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="px-3 py-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors rounded-md hover:bg-white/5"
            >
              {link.label}
            </a>
          ))}
        </div>

        <div className="flex items-center gap-2">
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  asChild
                  className="text-muted-foreground hover:text-foreground"
                >
                  <a
                    href="https://github.com/Yotsawarit/bnn-code"
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label="GitHub Repository"
                  >
                    <Github className="w-5 h-5" />
                  </a>
                </Button>
              </TooltipTrigger>
              <TooltipContent>View on GitHub</TooltipContent>
            </Tooltip>
          </TooltipProvider>
          <Button
            size="sm"
            className="bg-amber-500 text-zinc-950 hover:bg-amber-400 font-semibold shadow-lg shadow-amber-500/20"
            asChild
          >
            <a href="#installation">
              <Download className="w-4 h-4 mr-1.5" />
              Install
            </a>
          </Button>
        </div>
      </nav>
    </header>
  );
}

/* ──────────────────────────── Hero ──────────────────────────── */

function HeroSection() {
  return (
    <section className="relative min-h-screen flex flex-col items-center justify-center px-4 pt-20 pb-16 overflow-hidden">
      <div className="absolute inset-0 grid-pattern opacity-40" />
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-amber-500/5 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-0 left-0 right-0 h-40 bg-gradient-to-t from-background to-transparent pointer-events-none z-10" />

      <div className="relative z-10 max-w-4xl mx-auto text-center">
        <FadeIn>
          <Badge
            variant="outline"
            className="mb-6 border-amber-500/30 text-amber-400 bg-amber-500/5 px-3 py-1"
          >
            <Zap className="w-3 h-3 mr-1.5" />
            Powered by Binarized Neural Networks
          </Badge>
        </FadeIn>

        <FadeIn delay={0.1}>
          <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-extrabold tracking-tight leading-[1.1] mb-6">
            AI Coding Agent,{" "}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-400 via-amber-500 to-orange-500">
              Born in the Terminal
            </span>
          </h1>
        </FadeIn>

        <FadeIn delay={0.2}>
          <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto mb-10 leading-relaxed">
            BNN Code helps you understand, refactor, and test your codebase using
            on-device AI inference. Zero IDE lock-in. Runs entirely in your
            terminal.
          </p>
        </FadeIn>

        <FadeIn delay={0.3}>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 mb-6">
            <Button
              size="lg"
              className="bg-amber-500 text-zinc-950 hover:bg-amber-400 font-semibold shadow-lg shadow-amber-500/25 px-6"
              asChild
            >
              <a href="#installation">
                Get Started
                <ArrowRight className="w-4 h-4 ml-2" />
              </a>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="border-white/10 hover:bg-white/5 hover:border-white/20 px-6"
              asChild
            >
              <a
                href="https://github.com/Yotsawarit/bnn-code"
                target="_blank"
                rel="noopener noreferrer"
              >
                <Github className="w-4 h-4 mr-2" />
                GitHub
              </a>
            </Button>
          </div>
        </FadeIn>

        <FadeIn delay={0.35}>
          <div className="flex flex-wrap items-center justify-center gap-2 sm:gap-3">
            <a
              href="https://github.com/Yotsawarit/bnn-code"
              target="_blank"
              rel="noopener noreferrer"
              className="hover:opacity-80 transition-opacity"
            >
              { }
              <img
                src="https://img.shields.io/github/v/release/Yotsawarit/bnn-code?style=flat-square&color=18181b&labelColor=27272a&label=github"
                alt="GitHub release"
                className="h-5"
              />
            </a>
            <a
              href="https://crates.io/crates/bnn-code"
              target="_blank"
              rel="noopener noreferrer"
              className="hover:opacity-80 transition-opacity"
            >
              { }
              <img
                src="https://img.shields.io/crates/v/bnn-code?style=flat-square&color=18181b&labelColor=27272a&label=crates.io"
                alt="Crates.io version"
                className="h-5"
              />
            </a>
            <a
              href="https://docs.rs/bnn-code"
              target="_blank"
              rel="noopener noreferrer"
              className="hover:opacity-80 transition-opacity"
            >
              { }
              <img
                src="https://img.shields.io/docsrs/bnn-code?style=flat-square&color=18181b&labelColor=27272a&label=docs.rs"
                alt="docs.rs"
                className="h-5"
              />
            </a>
            <a
              href="https://github.com/Yotsawarit/bnn-code/actions"
              target="_blank"
              rel="noopener noreferrer"
              className="hover:opacity-80 transition-opacity"
            >
              { }
              <img
                src="https://github.com/Yotsawarit/bnn-code/actions/workflows/release.yml/badge.svg?style=flat-square&labelColor=27272a"
                alt="Build status"
                className="h-5"
              />
            </a>
            <a
              href="https://opensource.org/licenses/MIT"
              target="_blank"
              rel="noopener noreferrer"
              className="hover:opacity-80 transition-opacity"
            >
              { }
              <img
                src="https://img.shields.io/badge/License-MIT-yellow?style=flat-square&labelColor=27272a"
                alt="MIT License"
                className="h-5"
              />
            </a>
          </div>
        </FadeIn>
      </div>

      <FadeIn delay={0.5} className="relative z-10 w-full max-w-4xl mx-auto mt-14">
        <div className="relative rounded-2xl overflow-hidden border border-white/10 glow-amber">
          <Image
            src="/hero-bnn.png"
            alt="BNN Code — Terminal AI Coding Agent visualization"
            width={1344}
            height={768}
            className="w-full h-auto"
            priority
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background/60 via-transparent to-transparent" />
        </div>
      </FadeIn>
    </section>
  );
}

/* ──────────────────────────── Stats ──────────────────────────── */

function StatsSection() {
  const stats = [
    { value: 10, suffix: "+", label: "Languages Supported" },
    { value: 6, suffix: "", label: "Platform Binaries" },
    { value: 2, suffix: "", label: "Editor Integrations" },
    { value: 0, suffix: "", label: "IDE Lock-in", reverse: true },
  ];

  return (
    <section className="py-16 border-y border-white/5">
      <div className="max-w-4xl mx-auto px-4 sm:px-6">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
          {stats.map((stat) => (
            <FadeIn key={stat.label}>
              <div>
                {stat.reverse ? (
                  <span className="text-3xl md:text-4xl font-bold text-emerald-400">
                    Zero
                  </span>
                ) : (
                  <AnimatedCounter target={stat.value} suffix={stat.suffix} />
                )}
                <p className="text-sm text-muted-foreground mt-1.5">
                  {stat.label}
                </p>
              </div>
            </FadeIn>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ──────────────────────────── Features ──────────────────────────── */

function FeaturesSection() {
  const features = [
    {
      icon: Brain,
      title: "Code Understanding",
      description:
        "Index your entire codebase and ask questions in natural language. Get intelligent answers powered by BNN inference.",
    },
    {
      icon: FileCode2,
      title: "Multi-language Support",
      description:
        "Python, JavaScript, TypeScript, Rust, Go, Java, C++, Ruby, Swift, Kotlin — all first-class citizens.",
    },
    {
      icon: TreePine,
      title: "AST-aware Indexing",
      description:
        "Smart code chunking using tree-sitter grammars. Understand structure, not just text.",
    },
    {
      icon: Monitor,
      title: "Terminal-native UI",
      description:
        "Built with Ratatui + Crossterm. Full interactive TUI experience — no browser, no Electron, no bloat.",
    },
    {
      icon: Cpu,
      title: "BNN Inference",
      description:
        "On-device AI with ONNX Runtime. SSE4.2 compatible. Your code never leaves your machine.",
    },
    {
      icon: Database,
      title: "SQLite-backed Storage",
      description:
        "Fast local search and retrieval with SQLite. Zero network latency, zero config database.",
    },
    {
      icon: Puzzle,
      title: "Editor Integrations",
      description:
        "VS Code extension and Neovim plugin included out of the box. Seamless workflow integration.",
    },
  ];

  return (
    <section id="features" className="py-20 md:py-28 px-4 sm:px-6">
      <div className="max-w-6xl mx-auto">
        <SectionHeader
          badge="Features"
          title="Everything you need, nothing you don't"
          description="BNN Code packs powerful code intelligence into a lean terminal tool. No browser tabs, no cloud API calls, no subscription."
        />
        <StaggerContainer className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-5">
          {features.map((f) => (
            <FeatureCard key={f.title} {...f} />
          ))}
        </StaggerContainer>
      </div>
    </section>
  );
}

/* ──────────────────────────── Installation ──────────────────────────── */

function InstallationSection() {
  return (
    <section
      id="installation"
      className="py-20 md:py-28 px-4 sm:px-6 border-t border-white/5"
    >
      <div className="max-w-6xl mx-auto">
        <SectionHeader
          badge="Installation"
          title="Up and running in seconds"
          description="Install BNN Code with a single command. Pre-built binaries, crates.io, or build from source."
        />

        <div className="max-w-3xl mx-auto space-y-6">
          <FadeIn>
            <Tabs defaultValue="github" className="w-full">
              <TabsList className="bg-white/5 border border-white/5 w-full grid grid-cols-4 h-auto p-1">
                <TabsTrigger
                  value="github"
                  className="data-[state=active]:bg-amber-500/15 data-[state=active]:text-amber-400 text-muted-foreground py-2.5 text-sm"
                >
                  GitHub
                </TabsTrigger>
                <TabsTrigger
                  value="crates"
                  className="data-[state=active]:bg-amber-500/15 data-[state=active]:text-amber-400 text-muted-foreground py-2.5 text-sm"
                >
                  crates.io
                </TabsTrigger>
                <TabsTrigger
                  value="deb"
                  className="data-[state=active]:bg-amber-500/15 data-[state=active]:text-amber-400 text-muted-foreground py-2.5 text-sm"
                >
                  .deb
                </TabsTrigger>
                <TabsTrigger
                  value="source"
                  className="data-[state=active]:bg-amber-500/15 data-[state=active]:text-amber-400 text-muted-foreground py-2.5 text-sm"
                >
                  Source
                </TabsTrigger>
              </TabsList>

              <TabsContent value="github" className="mt-4">
                <CodeBlock
                  language="bash"
                  code={`# Linux (glibc)
tar -xzf bnn-code-linux-amd64.tar.gz
sudo mv bnn-code /usr/local/bin/

# macOS (Intel)
tar -xzf bnn-code-macos-amd64.tar.gz
sudo mv bnn-code /usr/local/bin/

# macOS (Apple Silicon)
tar -xzf bnn-code-macos-arm64.tar.gz
sudo mv bnn-code /usr/local/bin/

# Windows
unzip bnn-code-windows-amd64.exe.zip
# Move bnn-code.exe to a directory in your PATH`}
                />
              </TabsContent>

              <TabsContent value="crates" className="mt-4">
                <CodeBlock
                  language="bash"
                  code={`cargo install bnn-code`}
                />
              </TabsContent>

              <TabsContent value="deb" className="mt-4">
                <CodeBlock
                  language="bash"
                  code={`# Download the .deb package from the Releases page
sudo dpkg -i bnn-code_0.1.1_amd64.deb`}
                />
              </TabsContent>

              <TabsContent value="source" className="mt-4">
                <CodeBlock
                  language="bash"
                  code={`git clone https://github.com/Yotsawarit/bnn-code.git
cd bnn-code
cargo build --release
./target/release/bnn-code --help`}
                />
              </TabsContent>
            </Tabs>
          </FadeIn>
        </div>
      </div>
    </section>
  );
}

/* ──────────────────────────── Quick Start ──────────────────────────── */

function QuickStartSection() {
  return (
    <section className="py-20 md:py-28 px-4 sm:px-6 border-t border-white/5">
      <div className="max-w-6xl mx-auto">
        <SectionHeader
          badge="Quick Start"
          title="Three commands to get going"
          description="Index your project, search with natural language, and query with AI."
        />

        <div className="max-w-3xl mx-auto">
          <FadeIn>
            <CodeBlock
              language="bash"
              code={`# Index your codebase
$ bnn-code index --path /path/to/your/project

# Search for code patterns
$ bnn-code search "function that handles authentication"

# Start interactive TUI
$ bnn-code

# Get help
$ bnn-code --help`}
            />
          </FadeIn>
        </div>
      </div>
    </section>
  );
}

/* ──────────────────────────── Commands ──────────────────────────── */

function CommandsSection() {
  const commands = [
    {
      cmd: "bnn-code index",
      desc: "Index a codebase for search and retrieval",
    },
    {
      cmd: "bnn-code search",
      desc: "Search indexed code with natural language",
    },
    {
      cmd: "bnn-code query",
      desc: "Query with AI inference powered by BNN",
    },
    {
      cmd: "bnn-code",
      desc: "Launch the interactive Terminal UI",
    },
    {
      cmd: "bnn-code --help",
      desc: "Show full help and available options",
    },
  ];

  return (
    <section className="py-20 md:py-28 px-4 sm:px-6 border-t border-white/5">
      <div className="max-w-6xl mx-auto">
        <SectionHeader
          badge="Commands"
          title="Simple, powerful CLI"
          description="Everything accessible from your terminal with intuitive subcommands."
        />

        <FadeIn className="max-w-2xl mx-auto">
          <Card className="bg-card/50 backdrop-blur-sm border-white/5 overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow className="border-white/5 hover:bg-transparent">
                  <TableHead className="text-amber-400 font-mono text-sm">
                    Command
                  </TableHead>
                  <TableHead className="text-muted-foreground text-sm">
                    Description
                  </TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {commands.map(({ cmd, desc }) => (
                  <TableRow
                    key={cmd}
                    className="border-white/5 hover:bg-white/[0.02]"
                  >
                    <TableCell className="font-mono text-sm font-medium">
                      {cmd}
                    </TableCell>
                    <TableCell className="text-muted-foreground text-sm">
                      {desc}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </Card>
        </FadeIn>
      </div>
    </section>
  );
}

/* ──────────────────────────── Download Models ──────────────────────────── */

function DownloadModelsSection() {
  return (
    <section className="py-20 md:py-28 px-4 sm:px-6 border-t border-white/5">
      <div className="max-w-6xl mx-auto">
        <SectionHeader
          badge="Download Models"
          title="AI models, locally"
          description="Download the CodeBERTa-small model for on-device inference. No API keys, no cloud calls."
        />

        <div className="max-w-3xl mx-auto">
          <FadeIn>
            <CodeBlock
              language="bash"
              code={`# Download CodeBERTa-small model (recommended for most users)
bash scripts/download_model.sh

# Or use the Python script for more options
python3 scripts/download_model.py --model codeberta-small`}
            />
          </FadeIn>
          <FadeIn delay={0.1}>
            <div className="mt-6 grid sm:grid-cols-2 gap-4">
              <Card className="bg-card/50 backdrop-blur-sm border-white/5">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm flex items-center gap-2">
                    <Cpu className="w-4 h-4 text-amber-400" />
                    CodeBERTa-small
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription>
                    Recommended for most users. Good balance of speed and
                    accuracy. SSE4.2 compatible.
                  </CardDescription>
                </CardContent>
              </Card>
              <Card className="bg-card/50 backdrop-blur-sm border-white/5">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm flex items-center gap-2">
                    <HardDrive className="w-4 h-4 text-emerald-400" />
                    Local Only
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription>
                    All inference runs on-device. Your code never leaves your
                    machine. No network required after download.
                  </CardDescription>
                </CardContent>
              </Card>
            </div>
          </FadeIn>
        </div>
      </div>
    </section>
  );
}

/* ──────────────────────────── Editor Integrations ──────────────────────────── */

function EditorIntegrationsSection() {
  return (
    <section className="py-20 md:py-28 px-4 sm:px-6 border-t border-white/5">
      <div className="max-w-6xl mx-auto">
        <SectionHeader
          badge="Editor Integrations"
          title="Works with your editor, not against it"
          description="First-class integrations for the two most popular terminal-friendly editors."
        />

        <div className="grid md:grid-cols-2 gap-6 max-w-4xl mx-auto">
          <FadeIn>
            <Card className="bg-card/50 backdrop-blur-sm border-white/5 hover:border-amber-500/20 transition-all duration-300 h-full">
              <CardHeader>
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-10 h-10 rounded-lg bg-blue-500/10 flex items-center justify-center">
                    <Code2 className="w-5 h-5 text-blue-400" />
                  </div>
                  <CardTitle className="text-xl">VS Code</CardTitle>
                </div>
                <CardDescription className="text-muted-foreground leading-relaxed">
                  Install the extension from VS Code Marketplace or install
                  manually with the provided script.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <CodeBlock
                  language="bash"
                  code={`bash scripts/install-vscode.sh`}
                />
                <div className="space-y-2">
                  <p className="text-sm text-muted-foreground">
                    Open command palette{" "}
                    <kbd className="px-1.5 py-0.5 text-xs font-mono bg-white/5 border border-white/10 rounded">
                      Ctrl+Shift+P
                    </kbd>{" "}
                    and run:
                  </p>
                  <div className="space-y-1.5 pl-2">
                    {[
                      "BNN: Index Workspace",
                      "BNN: Search Code",
                      "BNN: Query with AI",
                    ].map((cmd) => (
                      <div
                        key={cmd}
                        className="flex items-center gap-2 text-sm"
                      >
                        <ChevronRight className="w-3 h-3 text-amber-400" />
                        <code className="font-mono text-amber-400/90">
                          {cmd}
                        </code>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </FadeIn>

          <FadeIn delay={0.1}>
            <Card className="bg-card/50 backdrop-blur-sm border-white/5 hover:border-emerald-500/20 transition-all duration-300 h-full">
              <CardHeader>
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-10 h-10 rounded-lg bg-emerald-500/10 flex items-center justify-center">
                    <Keyboard className="w-5 h-5 text-emerald-400" />
                  </div>
                  <CardTitle className="text-xl">Neovim</CardTitle>
                </div>
                <CardDescription className="text-muted-foreground leading-relaxed">
                  Full Neovim plugin with Lua configuration. Use your existing
                  leader key workflow.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <CodeBlock
                  language="bash"
                  code={`bash scripts/install-neovim.sh`}
                />
                <div className="space-y-2">
                  <p className="text-sm text-muted-foreground">
                    Available keymaps:
                  </p>
                  <div className="space-y-1.5 pl-2">
                    {[
                      { key: "<Leader>bn", desc: "Open BNN Code" },
                      { key: "<Leader>bi", desc: "Index workspace" },
                      { key: "<Leader>bs", desc: "Search code" },
                    ].map(({ key, desc }) => (
                      <div
                        key={key}
                        className="flex items-center gap-2 text-sm"
                      >
                        <kbd className="px-1.5 py-0.5 text-xs font-mono bg-white/5 border border-white/10 rounded text-emerald-400/90 min-w-[100px] text-center">
                          {key}
                        </kbd>
                        <span className="text-muted-foreground">{desc}</span>
                      </div>
                    ))}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    See{" "}
                    <code className="text-emerald-400/80 font-mono">
                      :help bnn-code
                    </code>{" "}
                    for full documentation
                  </p>
                </div>
              </CardContent>
            </Card>
          </FadeIn>
        </div>
      </div>
    </section>
  );
}

/* ──────────────────────────── Architecture ──────────────────────────── */

function ArchitectureSection() {
  return (
    <section
      id="architecture"
      className="py-20 md:py-28 px-4 sm:px-6 border-t border-white/5"
    >
      <div className="max-w-6xl mx-auto">
        <SectionHeader
          badge="Architecture"
          title="Clean layers, powerful engine"
          description="Built in Rust with a clear separation of concerns. From CLI to inference, every layer is optimized for performance."
        />
        <ArchitectureDiagram />
      </div>
    </section>
  );
}

/* ──────────────────────────── Supported Platforms ──────────────────────────── */

function PlatformsSection() {
  const platforms = [
    {
      platform: "Linux x86_64 (glibc)",
      binary: "bnn-code-linux-amd64.tar.gz",
    },
    {
      platform: "Linux x86_64 (static)",
      binary: "bnn-code-linux-amd64-static.tar.gz",
    },
    { platform: "macOS x86_64", binary: "bnn-code-macos-amd64.tar.gz" },
    { platform: "macOS ARM64", binary: "bnn-code-macos-arm64.tar.gz" },
    { platform: "Windows x86_64", binary: "bnn-code-windows-amd64.exe.zip" },
    { platform: "Deepin/Debian/Ubuntu", binary: "bnn-code_0.1.1_amd64.deb" },
  ];

  return (
    <section className="py-20 md:py-28 px-4 sm:px-6 border-t border-white/5">
      <div className="max-w-6xl mx-auto">
        <SectionHeader
          badge="Supported Platforms"
          title="Runs everywhere you do"
          description="Pre-built binaries for every major platform. Build from source if you prefer."
        />

        <FadeIn className="max-w-2xl mx-auto">
          <Card className="bg-card/50 backdrop-blur-sm border-white/5 overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow className="border-white/5 hover:bg-transparent">
                  <TableHead className="text-sm">Platform</TableHead>
                  <TableHead className="text-sm">Binary</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {platforms.map(({ platform, binary }) => (
                  <TableRow
                    key={platform}
                    className="border-white/5 hover:bg-white/[0.02]"
                  >
                    <TableCell className="font-medium text-sm">
                      {platform}
                    </TableCell>
                    <TableCell className="font-mono text-xs text-muted-foreground">
                      {binary}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </Card>
        </FadeIn>
      </div>
    </section>
  );
}

/* ──────────────────────────── Performance Benchmarks ──────────────────────────── */

function BenchmarksSection() {
  const benchmarks = [
    {
      metric: "Indexing Speed",
      value: "1,247 files",
      detail: "in 2.1 seconds",
      sub: "~594 files/sec with tree-sitter AST parsing",
      icon: Timer,
      color: "text-amber-400",
      bgColor: "bg-amber-500/10",
    },
    {
      metric: "Search Latency",
      value: "12ms",
      detail: "average query",
      sub: "SQLite FTS5 full-text search over 48K chunks",
      icon: Search,
      color: "text-cyan-400",
      bgColor: "bg-cyan-500/10",
    },
    {
      metric: "BNN Inference",
      value: "85ms",
      detail: "per query",
      sub: "CodeBERTa-small on CPU, SSE4.2 optimized",
      icon: Cpu,
      color: "text-violet-400",
      bgColor: "bg-violet-500/10",
    },
    {
      metric: "Binary Size",
      value: "~8.2 MB",
      detail: "release build",
      sub: "Stripped, statically linked. No runtime deps.",
      icon: HardDrive,
      color: "text-emerald-400",
      bgColor: "bg-emerald-500/10",
    },
    {
      metric: "Memory Usage",
      value: "~45 MB",
      detail: "at idle",
      sub: "Peak ~120 MB during indexing. SQLite + ONNX runtime.",
      icon: Layers,
      color: "text-rose-400",
      bgColor: "bg-rose-500/10",
    },
    {
      metric: "Startup Time",
      value: "<50ms",
      detail: "cold start",
      sub: "Native Rust binary. No JVM, no Electron overhead.",
      icon: Zap,
      color: "text-yellow-400",
      bgColor: "bg-yellow-500/10",
    },
  ];

  return (
    <section
      id="benchmarks"
      className="py-20 md:py-28 px-4 sm:px-6 border-t border-white/5"
    >
      <div className="max-w-6xl mx-auto">
        <SectionHeader
          badge="Performance Benchmarks"
          title="Fast by design"
          description="Rust-native performance with zero cold-start overhead. Every millisecond counts in your terminal."
        />

        <StaggerContainer className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-5 max-w-4xl mx-auto">
          {benchmarks.map((b) => (
            <motion.div key={b.metric} variants={staggerItem}>
              <Card className="bg-card/50 backdrop-blur-sm border-white/5 hover:border-white/10 transition-all duration-300 h-full">
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-sm text-muted-foreground font-medium">
                      {b.metric}
                    </CardTitle>
                    <div
                      className={`w-8 h-8 rounded-lg ${b.bgColor} flex items-center justify-center`}
                    >
                      <b.icon className={`w-4 h-4 ${b.color}`} />
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex items-baseline gap-2 mb-1">
                    <span className={`text-2xl font-bold ${b.color}`}>
                      {b.value}
                    </span>
                    <span className="text-sm text-muted-foreground">
                      {b.detail}
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground/70">{b.sub}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </StaggerContainer>

        <FadeIn delay={0.3} className="max-w-2xl mx-auto mt-8">
          <p className="text-xs text-center text-muted-foreground/50">
            Benchmarks measured on a mid-range laptop (4-core, 16 GB RAM, SSD).
            Results may vary by project size and hardware.
          </p>
        </FadeIn>
      </div>
    </section>
  );
}

/* ──────────────────────────── Project Structure ──────────────────────────── */

function ProjectStructureSection() {
  return (
    <section className="py-20 md:py-28 px-4 sm:px-6 border-t border-white/5">
      <div className="max-w-6xl mx-auto">
        <SectionHeader
          badge="Project Structure"
          title="Organized for clarity"
          description="A clean Rust project structure with clear separation between indexing, inference, retrieval, and UI layers."
        />

        <FadeIn className="max-w-2xl mx-auto">
          <Card className="bg-card/50 backdrop-blur-sm border-white/5">
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <FolderTree className="w-4 h-4 text-amber-400" />
                Source Tree
              </CardTitle>
            </CardHeader>
            <CardContent>
              <pre className="text-sm font-mono text-muted-foreground leading-loose overflow-x-auto">
                {`src/
├── cli/         # CLI argument parsing (clap)
├── indexer/     # Code indexing with tree-sitter AST
│   ├── chunker.rs
│   ├── database.rs
│   └── parser.rs
├── inference/   # ONNX Runtime + BNN inference
│   └── model.rs
├── retrieval/   # SQLite search and retrieval
│   └── search.rs
├── ui/          # Terminal UI (Ratatui)
│   ├── mod.rs
│   ├── streaming.rs
│   └── terminal.rs
├── utils/       # Shared utilities
│   ├── cache.rs
│   └── config.rs
└── main.rs`}
              </pre>
            </CardContent>
          </Card>
        </FadeIn>
      </div>
    </section>
  );
}

/* ──────────────────────────── Development ──────────────────────────── */

function DevelopmentSection() {
  return (
    <section className="py-20 md:py-28 px-4 sm:px-6 border-t border-white/5">
      <div className="max-w-6xl mx-auto">
        <SectionHeader
          badge="Development"
          title="Build it yourself"
          description="Standard Rust toolchain. Clone, check, test, and build."
        />

        <div className="max-w-3xl mx-auto">
          <FadeIn>
            <CodeBlock
              language="bash"
              code={`# Check
cargo check

# Run tests
cargo test

# Build release
cargo build --release

# Build static binary
RUSTFLAGS="-C target-feature=+crt-static" cargo build --release`}
            />
          </FadeIn>
        </div>
      </div>
    </section>
  );
}

/* ──────────────────────────── Roadmap ──────────────────────────── */

function RoadmapSection() {
  const phases = [
    {
      phase: "v0.1 — Foundation",
      status: "done" as const,
      items: [
        "CLI with clap argument parsing",
        "tree-sitter AST-aware indexing",
        "SQLite FTS search and retrieval",
        "ONNX Runtime BNN inference",
        "Interactive TUI with Ratatui",
        "VS Code extension + Neovim plugin",
      ],
    },
    {
      phase: "v0.2 — Intelligence",
      status: "planned" as const,
      items: [
        "Multi-file codebase understanding",
        "Refactoring suggestions via BNN",
        "Automated test generation hints",
        "Git history-aware context",
        "Configurable inference models",
      ],
    },
    {
      phase: "v0.3 — Ecosystem",
      status: "future" as const,
      items: [
        "LSP server for deep editor integration",
        "Plugin system for custom analyzers",
        "Web dashboard (optional)",
        "Team sharing via local network",
        "Additional BNN architectures",
      ],
    },
  ];

  const statusStyles = {
    done: {
      badge: "Shipped",
      badgeClass: "bg-emerald-500/15 text-emerald-400 border-emerald-500/30",
      lineClass: "border-emerald-500/30",
      dotClass: "bg-emerald-400",
    },
    planned: {
      badge: "Planned",
      badgeClass: "bg-amber-500/15 text-amber-400 border-amber-500/30",
      lineClass: "border-amber-500/30",
      dotClass: "bg-amber-400",
    },
    future: {
      badge: "Future",
      badgeClass: "bg-white/5 text-muted-foreground border-white/10",
      lineClass: "border-white/5",
      dotClass: "bg-muted-foreground/40",
    },
  };

  return (
    <section
      id="roadmap"
      className="py-20 md:py-28 px-4 sm:px-6 border-t border-white/5"
    >
      <div className="max-w-6xl mx-auto">
        <SectionHeader
          badge="Roadmap"
          title="Where we're headed"
          description="From foundation to ecosystem. Here's the plan for BNN Code."
        />

        <div className="max-w-3xl mx-auto space-y-6">
          {phases.map((phase, i) => {
            const style = statusStyles[phase.status];
            return (
              <FadeIn key={phase.phase} delay={i * 0.1}>
                <Card
                  className={`bg-card/50 backdrop-blur-sm border-white/5 hover:border-white/10 transition-all duration-300`}
                >
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg font-semibold flex items-center gap-3">
                        <div
                          className={`w-3 h-3 rounded-full ${style.dotClass}`}
                        />
                        {phase.phase}
                      </CardTitle>
                      <Badge
                        variant="outline"
                        className={style.badgeClass}
                      >
                        {style.badge}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2 ml-6">
                      {phase.items.map((item) => (
                        <li
                          key={item}
                          className="flex items-start gap-2 text-sm text-muted-foreground"
                        >
                          <ChevronRight
                            className={`w-4 h-4 mt-0.5 shrink-0 ${
                              phase.status === "done"
                                ? "text-emerald-400"
                                : phase.status === "planned"
                                  ? "text-amber-400"
                                  : "text-muted-foreground/30"
                            }`}
                          />
                          {item}
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              </FadeIn>
            );
          })}
        </div>
      </div>
    </section>
  );
}

/* ──────────────────────────── Contributing ──────────────────────────── */

function ContributingSection() {
  const steps = [
    {
      icon: GitBranch,
      title: "Fork & Clone",
      description:
        "Fork the repository and clone it locally. Create a feature branch from main.",
    },
    {
      icon: Hammer,
      title: "Develop & Test",
      description:
        'Run cargo check and cargo test frequently. Follow the existing code style and module structure.',
    },
    {
      icon: FileText,
      title: "Document",
      description:
        "Add doc comments to public APIs. Update README.md if user-facing behavior changes.",
    },
    {
      icon: GitPullRequest,
      title: "Pull Request",
      description:
        "Open a PR against the main branch. Describe your changes clearly and link any related issues.",
    },
  ];

  return (
    <section className="py-20 md:py-28 px-4 sm:px-6 border-t border-white/5">
      <div className="max-w-6xl mx-auto">
        <SectionHeader
          badge="Contributing"
          title="We welcome contributions"
          description="BNN Code is open-source under MIT. Every contribution — bug fix, feature, or docs — is appreciated."
        />

        <StaggerContainer className="grid grid-cols-1 sm:grid-cols-2 gap-4 md:gap-5 max-w-4xl mx-auto">
          {steps.map((step) => (
            <motion.div key={step.title} variants={staggerItem}>
              <Card className="bg-card/50 backdrop-blur-sm border-white/5 hover:border-white/10 transition-all duration-300 h-full">
                <CardHeader className="pb-3">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-lg bg-amber-500/10 flex items-center justify-center shrink-0">
                      <step.icon className="w-4.5 h-4.5 text-amber-400" />
                    </div>
                    <CardTitle className="text-base">{step.title}</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-muted-foreground leading-relaxed">
                    {step.description}
                  </CardDescription>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </StaggerContainer>

        <FadeIn delay={0.3} className="max-w-3xl mx-auto mt-8">
          <Card className="bg-card/50 backdrop-blur-sm border-amber-500/10">
            <CardContent className="flex flex-col sm:flex-row items-center justify-between gap-4 py-5 px-6">
              <div>
                <p className="text-sm font-medium">Ready to contribute?</p>
                <p className="text-xs text-muted-foreground mt-0.5">
                  Read the full contributing guidelines on GitHub.
                </p>
              </div>
              <Button
                variant="outline"
                className="border-amber-500/30 text-amber-400 hover:bg-amber-500/10 hover:border-amber-500/50 shrink-0"
                asChild
              >
                <a
                  href="https://github.com/Yotsawarit/bnn-code"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <Github className="w-4 h-4 mr-2" />
                  Open Repository
                </a>
              </Button>
            </CardContent>
          </Card>
        </FadeIn>
      </div>
    </section>
  );
}

/* ──────────────────────────── References ──────────────────────────── */

function ReferencesSection() {
  const refs = [
    {
      title: "Binarized Neural Networks",
      description:
        "Binarized Neural Networks: Training Deep Neural Networks with Weights and Activations Constrained to +1 or -1 — Courbariaux et al., 2016",
      tag: "Paper",
    },
    {
      title: "tree-sitter",
      description:
        "An incremental parsing system for programming tools. Used for AST-aware code chunking in the indexer.",
      tag: "Tool",
    },
    {
      title: "ONNX Runtime",
      description:
        "Cross-platform, high-performance ML inference engine. Powers the BNN model execution on CPU.",
      tag: "Runtime",
    },
    {
      title: "CodeBERTa",
      description:
        "A small, efficient pre-trained model for code understanding. The default model used by BNN Code.",
      tag: "Model",
    },
    {
      title: "Ratatui",
      description:
        "Rust library for building terminal user interfaces. Provides the interactive TUI experience.",
      tag: "Library",
    },
    {
      title: "SQLite FTS5",
      description:
        "Full-text search extension for SQLite. Powers fast code retrieval and pattern matching.",
      tag: "Engine",
    },
  ];

  return (
    <section className="py-20 md:py-28 px-4 sm:px-6 border-t border-white/5">
      <div className="max-w-6xl mx-auto">
        <SectionHeader
          badge="References"
          title="Built on great technology"
          description="BNN Code stands on the shoulders of open-source research and tools."
        />

        <StaggerContainer className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-5 max-w-5xl mx-auto">
          {refs.map((ref) => (
            <motion.div key={ref.title} variants={staggerItem}>
              <Card className="group bg-card/50 backdrop-blur-sm border-white/5 hover:border-white/10 transition-all duration-300 h-full">
                <CardHeader className="pb-2">
                  <div className="flex items-start justify-between gap-2">
                    <CardTitle className="text-base font-semibold leading-snug">
                      {ref.title}
                    </CardTitle>
                    <Badge
                      variant="secondary"
                      className="bg-white/5 text-muted-foreground text-[10px] shrink-0"
                    >
                      {ref.tag}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-muted-foreground leading-relaxed text-sm">
                    {ref.description}
                  </CardDescription>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </StaggerContainer>
      </div>
    </section>
  );
}

/* ──────────────────────────── CTA ──────────────────────────── */

function CTASection() {
  return (
    <section className="py-20 md:py-28 px-4 sm:px-6 border-t border-white/5">
      <div className="max-w-3xl mx-auto text-center">
        <FadeIn>
          <div className="rounded-2xl border border-amber-500/20 bg-gradient-to-b from-amber-500/5 to-transparent p-8 md:p-12 glow-amber">
            <Terminal className="w-10 h-10 text-amber-400 mx-auto mb-4" />
            <h2 className="text-2xl md:text-3xl font-bold mb-3">
              Ready to code smarter?
            </h2>
            <p className="text-muted-foreground mb-8 max-w-lg mx-auto leading-relaxed">
              Install BNN Code and start understanding your codebase with
              on-device AI. No sign-up, no API key, no cloud.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
              <Button
                size="lg"
                className="bg-amber-500 text-zinc-950 hover:bg-amber-400 font-semibold shadow-lg shadow-amber-500/25 px-8"
                asChild
              >
                <a
                  href="https://github.com/Yotsawarit/bnn-code/releases"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <Download className="w-4 h-4 mr-2" />
                  Download Latest Release
                </a>
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-white/10 hover:bg-white/5 hover:border-white/20 px-8"
                asChild
              >
                <a
                  href="https://github.com/Yotsawarit/bnn-code"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <GitBranch className="w-4 h-4 mr-2" />
                  View Source
                </a>
              </Button>
            </div>
          </div>
        </FadeIn>
      </div>
    </section>
  );
}

/* ──────────────────────────── Footer ──────────────────────────── */

function Footer() {
  return (
    <footer className="border-t border-white/5 py-8 px-4 sm:px-6">
      <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Terminal className="w-4 h-4 text-amber-400" />
          <span>BNN Code</span>
          <Separator
            orientation="vertical"
            className="h-4 bg-white/10"
          />
          <span>MIT License</span>
        </div>
        <p className="text-sm text-muted-foreground">
          &copy; {new Date().getFullYear()} Mr. Yotsawarit Pudpong. All rights
          reserved.
        </p>
        <div className="flex items-center gap-4">
          <a
            href="https://github.com/Yotsawarit/bnn-code"
            target="_blank"
            rel="noopener noreferrer"
            className="text-muted-foreground hover:text-foreground transition-colors"
            aria-label="GitHub"
          >
            <Github className="w-5 h-5" />
          </a>
          <a
            href="https://crates.io/crates/bnn-code"
            target="_blank"
            rel="noopener noreferrer"
            className="text-muted-foreground hover:text-foreground transition-colors"
            aria-label="crates.io"
          >
            <Package className="w-5 h-5" />
          </a>
        </div>
      </div>
    </footer>
  );
}

/* ══════════════════════════════════════════════════════════════════════ */
/*                            MAIN PAGE                                 */
/* ══════════════════════════════════════════════════════════════════════ */

export default function HomePage() {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-1">
        <HeroSection />
        <StatsSection />
        <FeaturesSection />
        <DemoSection />
        <InstallationSection />
        <QuickStartSection />
        <CommandsSection />
        <DownloadModelsSection />
        <EditorIntegrationsSection />
        <ArchitectureSection />
        <PlatformsSection />
        <BenchmarksSection />
        <ProjectStructureSection />
        <DevelopmentSection />
        <RoadmapSection />
        <ContributingSection />
        <ReferencesSection />
        <CTASection />
      </main>
      <Footer />
    </div>
  );
}