import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "BNN Code — Terminal-Native AI Coding Agent",
  description:
    "BNN Code is a terminal-based AI coding assistant powered by Binarized Neural Networks. Index, search, and understand your codebase entirely in your terminal.",
  keywords: [
    "BNN Code",
    "AI coding assistant",
    "terminal",
    "binarized neural networks",
    "code understanding",
    "tree-sitter",
    "ONNX",
    "Rust",
  ],
  authors: [{ name: "Mr. Yotsawarit Pudpong" }],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
  openGraph: {
    title: "BNN Code — Terminal-Native AI Coding Agent",
    description:
      "Terminal-based AI coding assistant powered by Binarized Neural Networks. Zero IDE lock-in.",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}